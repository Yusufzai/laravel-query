import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: [
                
                'resources/scss/light/a.scss',
                'resources/scss/light/b.scss',
                'resources/scss/light/c.scss',

                'resources/scss/dark/a.scss',
                'resources/scss/dark/b.scss',
                'resources/scss/dark/c.scss',

                'resources/js/a.js',
                'resources/js/b.js',
                'resources/js/c.js',


                // RTL

                'resources/rtl/scss/light/a.scss',
                'resources/rtl/scss/light/b.scss',
                'resources/rtl/scss/light/c.scss',

                'resources/rtl/scss/dark/a.scss',
                'resources/rtl/scss/dark/b.scss',
                'resources/rtl/scss/dark/c.scss',

                'resources/rtl/js/a.js',
                'resources/rtl/js/b.js',
                'resources/rtl/js/c.js',
            
            ],
            refresh: true,
        }),
    ],
});
