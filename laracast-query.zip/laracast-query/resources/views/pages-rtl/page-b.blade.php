<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page B</title>

    {{-- @vite(['resources/rtl/scss/b.scss']) --}}

    @vite(['resources/rtl/scss/light/b.scss'])
    @vite(['resources/rtl/scss/dark/b.scss'])
    
</head>
<body>

    <ul>
        <li><a href="/rtl/">page a</a></li>
        <li><a href="/rtl/b">page b</a></li>
        <li><a href="/rtl/c">page c</a></li>
    </ul>

    <h2>Hi there, I am page b and I belongs to RTL version</h2>

    <ul>
        <li><a href="/">Navigate to LTR</a></li>
    </ul>

    @vite(['resources/rtl/js/b.js'])
    
</body>
</html>