<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page C</title>

    {{-- @vite(['resources/rtl/scss/c.scss']) --}}

    @vite(['resources/rtl/scss/light/c.scss'])
    @vite(['resources/rtl/scss/dark/c.scss'])
    
</head>
<body>

    <ul>
        <li><a href="/rtl/">page a</a></li>
        <li><a href="/rtl/b">page b</a></li>
        <li><a href="/rtl/c">page c</a></li>
    </ul>

    <h3>Hi there, I am page c and I belongs to RTL version</h3>

    <ul>
        <li><a href="/">Navigate to LTR</a></li>
    </ul>

    @vite(['resources/rtl/js/c.js'])
    
</body>
</html>