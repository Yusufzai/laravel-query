<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page C</title>

    @vite(['resources/scss/light/c.scss'])
    @vite(['resources/scss/dark/c.scss'])
    
</head>
<body>

    <ul>
        <li><a href="/">page a</a></li>
        <li><a href="/b">page b</a></li>
        <li><a href="/c">page c</a></li>
    </ul>

    <h3>Hi there, I am page c and I belongs to LTR version</h3>

    <ul>
        <li><a href="/rtl/">Navigate to RTL</a></li>
    </ul>
    
    @vite(['resources/js/c.js'])
</body>
</html>