<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page A</title>


    @vite(['resources/scss/light/a.scss'])
    @vite(['resources/scss/dark/a.scss'])
    
</head>
<body>

    <ul>
        <li><a href="/">page a</a></li>
        <li><a href="/b">page b</a></li>
        <li><a href="/c">page c</a></li>
    </ul>
    

    <h1>Hi there, I am page a and I belongs to LTR version</h1>
    

    <ul>
        <li><a href="/rtl/">Navigate to RTL</a></li>
    </ul>
    

    @vite(['resources/js/a.js'])
    
</body>
</html>