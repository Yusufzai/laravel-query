<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('pages.page-a');
});

Route::get('/b', function () {
    return view('pages.page-b');
});

Route::get('/c', function () {
    return view('pages.page-c');
});


// RTL

Route::prefix('rtl')->group(function () {

    Route::get('/', function () {
        return view('pages-rtl.page-a');
    });

    Route::get('/b', function () {
        return view('pages-rtl.page-b');
    });

    Route::get('/c', function () {
        return view('pages-rtl.page-c');
    });

});

// Route::get('/', function () {
//     return view('welcome');
// });
