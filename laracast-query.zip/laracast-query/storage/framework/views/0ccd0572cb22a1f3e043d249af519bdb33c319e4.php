<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page B</title>

    
    
</head>
<body>

    <h5>Some HTML From Blade page-b</h5>
    
</body>
</html><?php /**PATH K:\laracast-query\resources\views/page-b.blade.php ENDPATH**/ ?>