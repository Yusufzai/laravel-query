<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page A</title>


    <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/a.scss']); ?>
    
    
    
</head>
<body>

    <ul>
        <li><a href="/">page a</a></li>
        <li><a href="/b">page b</a></li>
        <li><a href="/c">page c</a></li>
    </ul>
    

    <h5>Some HTML From Blade page-a</h5>
    
</body>
</html><?php /**PATH K:\laracast-query\resources\views/page-a.blade.php ENDPATH**/ ?>