<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page A</title>


    

    <?php echo app('Illuminate\Foundation\Vite')(['resources/rtl/scss/light/a.scss']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/rtl/scss/dark/a.scss']); ?>
    
</head>
<body>

    <ul>
        <li><a href="/rtl/">page a</a></li>
        <li><a href="/rtl/b">page b</a></li>
        <li><a href="/rtl/c">page c</a></li>
    </ul>
    

    <h1>Hi there, I am page a and I belongs to RTL version</h1>

    <ul>
        <li><a href="/">Navigate to LTR</a></li>
    </ul>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/rtl/js/a.js']); ?>
    
</body>
</html><?php /**PATH K:\laracast-query\resources\views/pages-rtl/page-a.blade.php ENDPATH**/ ?>